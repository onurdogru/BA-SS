﻿using System;

namespace CA_SampleCodes
{
    class Program
    {
        static void Main(string[] args)
        {

            //PascalCase => ilk harflerin büyük olması
            //camelCase => başlangıç harfi küçük diğer kelimelerin ilk harfleri büyük


            //Console.Write("Hello World!");
            //Console.Read();

            //Console.WriteLine("Hello World!");
            //Console.Read();

            Console.WriteLine("Hoşgeldiniz...");
            Console.ReadLine();
            Console.WriteLine("Lütfen adınızı yazın....");
            Console.ReadLine();
            Console.WriteLine("Lütfen soyadınızı yazın...");
            Console.ReadLine();
            Console.Write("lütfen bekleyin bilgilerinizi kontrol ediyorum...");
            Console.Beep(1000, 1000);
            Console.Beep(1500, 500);
            Console.Beep(1600, 500);
            Console.Beep(1650, 500);
            Console.Write("güncel borcunuz bulunmamaktadır...");
            Console.Read();


            /*
             burası çoklu yorum satırı.
             */
        }
    }
}
